//
//  TipoDeProblema.swift
//  entrenate
//
//  Created by user186524 on 5/16/21.
//

import UIKit

class TipoDeProblema: NSObject {
    
    var tema : String = ""
    
    init(tema: String) {
        self.tema = tema
    }

}
